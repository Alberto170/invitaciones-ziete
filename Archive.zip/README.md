tailwind css
npx tailwindcss -i ./css/input.css -o ./css/output.css --watch