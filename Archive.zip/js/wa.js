const message = "Hola mucho gusto, quisiera pedir mas informacion sobre sus invitaciones digitales para mi proximo evento";
const encodedMessage = encodeURIComponent(message);
console.log(encodedMessage); // Output: Hello%2C%20I%27d%20like%20to%20know%20more%20about%20your%20services.
